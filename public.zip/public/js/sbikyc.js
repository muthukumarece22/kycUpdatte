$(document).ready(function(){
	$("#login_btn").click(function(){
		alert("login_btn clicked");
	})
});